/* Controller */

#import <Cocoa/Cocoa.h>
#import "SAApplication.h"
#import "NTiChatApplescripts.h"
#import "NTLoginItemMgr.h"

@interface Controller : NSObject
{	
	IBOutlet id timeLimit;
	IBOutlet id timeLimitSlider;	
	IBOutlet id fileOwner;	
	IBOutlet id sbMenu;
	IBOutlet id toggleMenuItem;
	IBOutlet id prefsWindow;
	IBOutlet id aboutWindow;
	IBOutlet id loginItemButton;
	IBOutlet id statusMessageHeader;
	
  EventHotKeyRef _hotKeyRef;
  
	// store run applications name
	NSMutableArray* applications;
	NSMutableArray* blacklist;
	// StatusItem instance
	NSStatusItem *sbItem;
	NSMutableString	*previousActiveApplicationName;
	// state of Application
	bool active;
	bool cooperateiChat;
}

- (void)hideApplication:(id)application;
- (void)addApplication:(id)application;
- (void)removeApplication:(id)application;
- (void)addAllApplications;
- (BOOL)isLoginItem;
- (void)changeiChatStatus: (NSString *) message;
- (void)changeiChatIcon: (NSImage *)icon;
- (void)wink;

// Actions
- (IBAction)registerHotKey:(id)sender;
- (IBAction)toggleActive:(id)sender;
- (IBAction)addLoginItem:(id)sender;
- (IBAction)showPreferences:(id)sender;
- (IBAction)showAboutPanel:(id)sender;
- (IBAction)selectApplicationFromMenu:(id)sender;

- (IBAction)donate:(id)sender;
@end
